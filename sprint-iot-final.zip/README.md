# Sistema de Agricultura Inteligente

Este projeto é um sistema de agricultura inteligente desenvolvido para ajudar agricultores a otimizar suas colheitas por meio de recomendações baseadas em dados e inteligência artificial.

## Tecnologias Usadas
- Python
- SQLite
- Modelos de IA
- GitHub Actions para CI/CD

## Instalação
1. Clone o repositório: `git clone https://github.com/Bernas01/sprint-iot-final.git`
2. Instale as dependências: `pip install -r requirements.txt`
3. Execute o script principal: `python main.py`

## Contribuindo
Contribuições são bem-vindas! Consulte [CONTRIBUTING.md](CONTRIBUTING.md) para saber como começar.
