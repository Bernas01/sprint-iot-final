# Código de Conduta

Para manter um ambiente acolhedor, todos os contribuidores e mantenedores deste projeto devem seguir estas diretrizes:
- Trate todos com respeito e profissionalismo.
- Evite linguagem ofensiva e ataques pessoais.
- Contribua de maneira construtiva e aberta ao feedback.
