# Arquitetura do Sistema

O sistema é composto por módulos independentes que interagem para fornecer recomendações agrícolas otimizadas.
