# Instalação e Configuração

Para instalar o sistema, siga as etapas no arquivo README.md.
