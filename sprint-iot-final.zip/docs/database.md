# Estrutura e Configuração do Banco de Dados

Este documento explica como configurar e utilizar o banco de dados utilizado pelo sistema.
