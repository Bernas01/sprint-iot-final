# Guia de Contribuição

Contribuições são sempre bem-vindas! Para começar, siga as etapas abaixo:

1. Faça um fork deste repositório.
2. Crie uma branch para sua feature (`git checkout -b minha-feature`).
3. Faça commit das suas alterações (`git commit -m 'Adiciona nova feature'`).
4. Envie para o branch (`git push origin minha-feature`).
5. Crie um novo Pull Request.

Certifique-se de que seu código segue o padrão do projeto e que todos os testes estejam passando.
